#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
/* Global declarations */
/* Variables */
int charClass;
char lexeme[100];
char nextChar;
int lexLen;
int token;
int nextToken;
FILE *in_fp;
char nextkey;

/* Function declarations */
int lookup(char ch);
void addChar(void);
void getChar(void);
void getNonBlank(void);
int lex(void);
void error2(void);




/* Character classes */
#define LETTER 0
#define DIGIT 1
#define UNKNOWN 99
#define Start 3
#define End 4

/* Token codes */
#define INT_LIT 10
#define IDENT 11
#define ASSIGN_OP 20
#define ADD_OP 21
#define SUB_OP 22
#define MULT_OP 23
#define DIV_OP 24
#define LEFT_PAREN 25
#define RIGHT_PAREN 26
#define MOD_OP 27
#define COMMA 28
#define SEMICOLON 29
#define LEFT_BRACK 30
#define RIGHT_BRACK 31
#define DOT 32
#define LESS_THAN 33
#define GREATER_THAN 34
#define LESS_THAN_EQUAL 35
#define GREATER_THAN_EQUAL 36
#define IF_CODE 37
#define Loop 39
#define Num 40
#define EQUALTO 41
#define NOEQUAL 42

int lookup(char ch) {

//  == cant be passed in

// <=
	 switch (ch) { // look at char to see what it is and if pass a case then nexttoken will be updated
		 case '(':
			 addChar();
			 nextToken = LEFT_PAREN;
			 break;
		 case ')':
			 addChar();
			 nextToken = RIGHT_PAREN;
			 break;
		 case '+':
			 addChar();
			 nextToken = ADD_OP;
			 break;
		 case '-':
			 addChar();
			 nextToken = SUB_OP;
			 break;
		 case '*':
			 addChar();
			 nextToken = MULT_OP;
			 break;
		 case '/':
			 addChar();
			 nextToken = DIV_OP;
			 break;
		 case '=':
			 addChar();
			 nextToken = ASSIGN_OP;
			 break;
		 case '%':
			 addChar();
			 nextToken = MOD_OP;
			 break;
		 case ';':
			 addChar();
			 nextToken = SEMICOLON;
			 break;
		 case ',':
			 addChar();
			 nextToken = COMMA;
			 break;
		 case '{':
			 addChar();
			 nextToken = LEFT_BRACK;
			 break;
		 case '}':
			 addChar();
			 nextToken = RIGHT_BRACK;
			 break;
		 case '.':
			 addChar();
			 nextToken = DOT;
			 break;
		 case '<':
			 addChar();
			 nextToken = LESS_THAN;
			 break;
		 case '>':
			 addChar();
			 nextToken = GREATER_THAN;
			 break;
     case '^':
       addChar();
			 nextToken = Start;
			 break;
     case '$':
      addChar();
      nextToken = End;
      break;
     case '#':
      addChar();
      nextToken = Num;
      break;
    
     case '!':
      addChar();
      nextToken = NOEQUAL;
      break;
		 default:
			 addChar();
			 nextToken = EOF;
			 break;
	 }
	 return nextToken;
}
void addChar(void) {
	if (lexLen <= 98) {
		lexeme[lexLen++] = nextChar;
		lexeme[lexLen] = '\0';
	} else
	printf("Error - lexeme is too long \n");
}


/******************************************************/
/* getChar - a function to get the next character of
 input and determine its character class 
 
 This language transitions on every possible character
 */
void getChar(void) {
	 if ((nextChar = getc(in_fp)) != EOF) {
		 if (isalpha(nextChar)) 
     /// (nextChar >= 65 && nextChar <= 90 ) ||
     /// (nextChar >= 97 && nextChar <= 122) || 
		 	charClass = LETTER;
         
     
		 else if (isdigit(nextChar))
     /// (nextChar >= 48 && nextChar <= 57) || 
		 	charClass = DIGIT;
		 else
		 	charClass = UNKNOWN;
	 } else
	 	charClass = EOF;
}


/******************************************************/
/* getNonBlank - a function to call getChar until it
 returns a non-whitespace character */
void getNonBlank(void) {
	while (isspace(nextChar))
	getChar();
}

void error2(void){
	 printf("ERROR STOP");
   exit(0);
}


/******************************************************/
/* lex - a simple lexical analyzer for arithmetic
 expressions */
int x;
int lex(void) {
	 lexLen = 0;
	 getNonBlank();
   int x;
   int y;
	 switch (charClass) {
		/* Identifiers */
    /*  [a-zA-Z][a-zA-Z0-9]*  is the regular expression for an identifier */
		 case LETTER:
       y =1;
			 addChar();
			 getChar();
			 while (charClass == LETTER) {
         y++;
				 addChar();
				 getChar();
			 } // finds keyword and change token based on it
      if(y<=8 && y>=6 && lexeme[0]!='l' && lexeme[0] !='c' && lexeme[0] != 'n' ){
			 nextToken = IDENT;
      }
      else if(lexeme[0]=='l'&&lexeme[1]=='o'&&lexeme[2]=='o'&&lexeme[3]=='p') {
        nextToken=Loop;
      }
       
else if(lexeme[0]=='c'&&lexeme[1]=='o'&&lexeme[2]=='n' ) {
        nextToken=IF_CODE;
      }
  else if((lexeme[1]!='o'||lexeme[2]!='o'||lexeme[3]!='p') && y>=6 && y<=8){
        nextToken= IDENT;
        }
       
     else{
       error2();
     }
     break;
		/* Integer literals */
    /*  [0-9]+  is the regular expression for an integer */

    /*  [0-9]*.[0-9]+[f|d]?  is the regular expression for an FLOAT_LIT */
    // .0
    // 0.0
    // 0.0324f
    // 0.0324d
     //// 8978176728 sadghsajg326173821
		 case DIGIT:
			 addChar();
			 getChar();
			 while (charClass == DIGIT) {
				 addChar();
				 getChar();
			 }
       if( nextChar == 'v' || nextChar == 'r' || nextChar == 'e' ){
			  	 addChar();
				   getChar();
        }
       if( nextChar != '.'){
			 nextToken = INT_LIT;
       } else {
         error2();
  			// addChar();
	  		// getChar();
		  	 while (charClass == DIGIT) {
			  	 addChar();
				   getChar();
           }
        if( nextChar == 'v' || nextChar == 'r' || nextChar == 'e' ){
			  	 addChar();
				   getChar();
        }
           
			  //nextToken = FLOAT_LIT;
       }
		 	break;
		/* Parentheses and operators */
    /*  ^[a-zA-Z0-9]  is the regular expression for an special charater */
		 case UNKNOWN:
       if( nextChar == '.'){
  			 addChar();
	  		 getChar();
         if(charClass == DIGIT ){
		  	    while (charClass == DIGIT) {
			  	    addChar();
				      getChar();
			      }
            if( nextChar == 'd' || nextChar == 'f' ){
			  	    addChar();
				      getChar();
            }
			    //  nextToken = FLOAT_LIT;
          }
          nextToken = DOT;
       } else {
			  lookup(nextChar);
			  getChar();
        if ( nextToken == LESS_THAN && nextChar == '=' ) {
          addChar();
          getChar();
          nextToken = LESS_THAN_EQUAL;
        } else if ( nextToken == GREATER_THAN && nextChar == '=' ) {
          addChar();
          getChar();
          nextToken = GREATER_THAN_EQUAL;
        }else if ( nextToken == ASSIGN_OP && nextChar == '=' ) {
          addChar();
          getChar();
          nextToken = EQUALTO;
          }
         
       }
			 break;
			/* EOF */
		case EOF:
			 nextToken = EOF;
			 lexeme[0] = 'E';
			 lexeme[1] = 'O';
			 lexeme[2] = 'F';
			 lexeme[3] = '\0';
		 	break;
    case Start:
      nextToken= Start;
     
	 } /* End of switch */
  switch(nextToken){
    case 3: //print out token name
    printf("Next token is: Start, Next lexeme is %s\n", lexeme);
    break;
    case 4:
    printf("Next token is: End, Next lexeme is %s\n", lexeme);
    break;
    
     case 10:
    printf("Next token is: Int_Lit, Next lexeme is %s\n", lexeme);
    break;
    
    case 11:
    printf("Next token is: IDENT, Next lexeme is %s\n", lexeme);
    break;
     
    case 20:
    printf("Next token is: Assign_op, Next lexeme is %s\n", lexeme);
    break;
    
     case 21:
    printf("Next token is: Add_op, Next lexeme is %s\n", lexeme);
    break;
    
     case 22:
    printf("Next token is: Sub_op, Next lexeme is %s\n", lexeme);
    break;
    
     case 23:
    printf("Next token is: Mult_op, Next lexeme is %s\n", lexeme);
    break;
    
     case 24:
    printf("Next token is:Div_op, Next lexeme is %s\n", lexeme);
    break;
    
     case 25:
    printf("Next token is: Left_paren, Next lexeme is %s\n", lexeme);
    break;
    
     case 26:
    printf("Next token is: right_paren, Next lexeme is %s\n", lexeme);
    break;
    
      case 27:
    printf("Next token is: Mod_op, Next lexeme is %s\n", lexeme);
    break;
    
      case 30:
    printf("Next token is: Left_Brack, Next lexeme is %s\n", lexeme);
    break;
    
      case 31:
    printf("Next token is: right_brack, Next lexeme is %s\n", lexeme);
    break;
    
      case 33:
    printf("Next token is: Less_than, Next lexeme is %s\n", lexeme);
    break;
    
      case 34:
    printf("Next token is: Greater_than, Next lexeme is %s\n", lexeme);
    break;
    
      case 35:
    printf("Next token is: Less_Than_equal, Next lexeme is %s\n", lexeme);
    break;
    
      case 36:
    printf("Next token is: Greater_than_Equal, Next lexeme is %s\n", lexeme);
    break;
    
      case 37:
    printf("Next token is: IF_code, Next lexeme is %s\n", lexeme);
    break;
      
    case 39:
    printf("Next token is: Loop, Next lexeme is %s\n", lexeme);
    break;

      case 40:
    printf("Next token is: Num keyword, Next lexeme is %s\n", lexeme);
    break;
    
      case 41:
    printf("Next token is: Equal_to, Next lexeme is %s\n", lexeme);
    break;
    
      case 42:
    printf("Next token is: Noequal, Next lexeme is %s\n", lexeme);
    break;

      case 29:
    printf("Next token is: Semicolon, Next lexeme is %s\n", lexeme);
    break;
    
    
  }
//	 printf("Next token is: %d, Next lexeme is %s\n",
//	 nextToken, lexeme);
	 return nextToken;
} /* End of function lex */